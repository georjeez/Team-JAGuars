Team name:
Team JAGuars

Members:
- Jasmeet
- Aidyn
- Georgina 

Project idea:
Our website is a documentation website that will contain facts about Jaguars, as well as having interactive features such as a quiz to test the reader's knowledge learned from the website.